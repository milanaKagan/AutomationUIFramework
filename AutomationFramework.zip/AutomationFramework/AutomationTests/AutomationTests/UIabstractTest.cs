﻿using System;
using System.Configuration;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using static AutomationFramework.Enums.Enums;


namespace AutomationFramework.AutomationTests
{
	public class UIabstractTest
	{
		private readonly string baseUrl = ConfigurationManager.AppSettings["BaseURL"];
		private readonly string browserType = ConfigurationManager.AppSettings["BrowserType"];
		public IWebDriver Driver;

        private BrowserType BrowserPicker()
        {

            if (browserType.ToLower().Equals("chrome"))
                return BrowserType.Chrome;
            else if (browserType.ToLower().Equals("edge"))
                return BrowserType.Edge;
            else
                return BrowserType.Chrome;
        }
        private void Init(string url, BrowserType browserType, int timeOut = 20)
        {

            Console.WriteLine("[Info]Init Driver Start");

            if (url == null || url.Equals(""))
            {
                Console.WriteLine("URL not exists");
                return;
            }

            try
            {
                string baseUrl = url;
                if (browserType == BrowserType.Edge)
				{
					Microsoft.Edge.SeleniumTools.EdgeOptions edgeOptions = new Microsoft.Edge.SeleniumTools.EdgeOptions();
                    edgeOptions.UseChromium = true;
                    Driver = new Microsoft.Edge.SeleniumTools.EdgeDriver(edgeOptions);
                }
                    
                else 
				{
                    Driver = new ChromeDriver();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("[Error]" + e + $"{browserType} driver int failed ");
            }

            try
            {
                Driver.Navigate().GoToUrl(url);

                WebDriverWait _wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(timeOut));
                
                if(_wait.Until(driver => driver.FindElement(By.CssSelector("#page"))) == null )
                {
                    Console.WriteLine($"[Error] Navigation took more than {timeOut} sec");
                    return;
				}
              

            }
            catch (Exception e)
            {
                Console.WriteLine("[Error]" + e + "Navigation to " + url + "failed");
            }
        }

        [SetUp]
		public void Before()
		{
			try
			{
				Console.WriteLine("[Info]TestStarted");
                Init(baseUrl, BrowserPicker());

			}
			catch (Exception e)
			{
				Console.WriteLine("[Error]Driver init failed" + e);
			}
		}
        
        [TearDown]
		public void After()
		{

			Driver.Close();
			Console.WriteLine("[Info]TestEnded");

		}
	}
}
