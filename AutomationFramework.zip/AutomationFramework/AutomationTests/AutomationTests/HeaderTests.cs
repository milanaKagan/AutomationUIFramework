﻿using AutomationFramework.AutomationBL;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;

namespace AutomationFramework.AutomationTests
{
	public class HeaderTests : UIabstractTest
	{
		private List<string> expectedTabsTitels = new List<string>() 
		{"women", "dresses", "t-shirts" };


		[Test]
		[Category("Header")]
		[Category("Sanity")]
		public void HeaderDispalyed()
		{
			var header = new HeaderPage(Driver);
			var expected = true;
			var actual = header.isDisplayed();

			Assert.AreEqual(expected, actual,
				message: $"Haeder displayed expecte: {expected}, actual: {actual}");

		}

		[Test]
		[Category("Header")]
		[Category("Sanity")]
		public void HeaderBanner()
		{
			var header = new HeaderPage(Driver);
			var expected = true;
			var actual = header.GetBanner() != null;

			Assert.AreEqual(expected, actual,
				message: $"Haeder banner displayed expecte: {expected}, actual: {actual}");

		}
		[Test]
		[Category("Header")]
		[Category("Sanity")]
		public void HeaderLogo()
		{
			var header = new HeaderPage(Driver);
			var expected = true;
			var actual = header.GetLogo() != null;

			Assert.AreEqual(expected, actual,
				message: $"Haeder banner displayed expecte: {expected}, actual: {actual}");

		}
		//same test scenarios for nav search box and card button

		[Test]
		[Category("Header")]
		[Category("Sanity")]
		public void HeaderTabs()
		{
			var header = new HeaderPage(Driver);

			var tabs = header.GetTopMenuTabsTitles();
			var result = tabs.Count == expectedTabsTitels.Count &&
				 expectedTabsTitels.All(tabs.Contains);
			Assert.IsTrue(result,
				message: $"Haeder Tabs Titles should be the same as expected displayed expected: {string.Join(",", expectedTabsTitels)}", 
				$"actual: {string.Join(",", tabs)}");

		}
		[Test]
		[Category("Header")]
		[Category("Sanity")]
		public void HeaderWomenTabOpen()
		{
			var header = new HeaderPage(Driver);

			var womenContainer = header.ContainerAfterTabButtonPressed("Women");
		
			Assert.IsTrue(womenContainer.Displayed,
				message: $"Haeder Women Container should be Displayed");

		}
	}
}
