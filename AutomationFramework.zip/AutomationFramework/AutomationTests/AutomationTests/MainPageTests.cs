﻿using AutomationFramework.AutomationBL;
using NUnit.Framework;


namespace AutomationFramework.AutomationTests
{
	public class MainPageTests: UIabstractTest
	{
		[Test]
		[Category("MainPage")]
		[Category("Sanity")]
		public void MainPageDispalyed()
		{
			var mainPage = new MainPage(Driver);
			var expected = true;
			var actual = mainPage.isDisplayed();
			Assert.AreEqual(expected, actual,
				message: $"Main page displayed expecte: {expected}, actual: {actual}");

		}
	}
}
