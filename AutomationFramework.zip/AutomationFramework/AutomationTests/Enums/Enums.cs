﻿

namespace AutomationFramework.Enums
{
	public class Enums
	{
        public enum BrowserType
        {
            Chrome,
            Edge
 
        }
        public enum SearchBy
        {
            Xpath,
            CssSelector
        }
    }
}
