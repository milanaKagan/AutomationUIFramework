﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using static AutomationFramework.Enums.Enums;

namespace AutomationFramework.AutomationBL
{
	public abstract class AbstractPage
	{
		protected IWebElement _pageRoot;
		protected IWebDriver _driver;
		protected string _pageExp;
		private WebDriverWait _wait;
		private int _timeOut;

		public AbstractPage(IWebDriver driver, string pageExp, SearchBy search = SearchBy.CssSelector, int timeout =10)
		{
			_driver = driver;
			_pageExp = pageExp;
			_wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(timeout));
			_timeOut = timeout;
			if (search == SearchBy.CssSelector)
				_pageRoot = _wait.Until(driver => driver.FindElement(By.CssSelector(_pageExp)));
			else if (search == SearchBy.Xpath)
				_pageRoot = _wait.Until(driver => driver.FindElement(By.XPath(_pageExp)));
		}
		public bool IsExist()
		{
			{
				try
				{
					if (_pageRoot == null)
					{
						_wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(_timeOut));
						_pageRoot = _wait.Until(driver => driver.FindElement(By.CssSelector(_pageExp)));
					}

					return _pageRoot != null;
				}
				catch (Exception e)
				{
					Console.WriteLine("[Error] Element Not Exists: " + e);
					return false;
				}
			}
		}
		public bool isDisplayed()
		{
			{
				try
				{
					if (!_pageRoot.Displayed)
					{
						_wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(_timeOut));
						_pageRoot = _wait.Until(driver => driver.FindElement(By.CssSelector(_pageExp)));
					}
						return _pageRoot.Displayed;
				}
				catch (Exception e)
				{
					Console.WriteLine("[Error] Element Not Displayed: " + e);
					return false;
				}
			}
		}

	}
}
