﻿using OpenQA.Selenium;


namespace AutomationFramework.AutomationBL
{
	public class MainPage : AbstractPage
	{
		private IWebDriver _driver;
		private const string _pageExp = "#page";

		public MainPage(IWebDriver driver) : base(driver, _pageExp)
		{
			_driver = driver;

		}

		public HeaderPage GetHeader()
		{
			return new HeaderPage(_driver);

		}
		

	}
}
