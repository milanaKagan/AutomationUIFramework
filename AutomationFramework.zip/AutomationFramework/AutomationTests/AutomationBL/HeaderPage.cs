﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;

namespace AutomationFramework.AutomationBL
{
	public class HeaderPage : AbstractPage
	{
		private IWebDriver _driver;
		private new const string _pageExp = "#header";
		private readonly string _bannerExp = ".banner";
		private readonly string _navigatorExp = ".nav";
		private readonly string _logoExp = "#header_logo";
		private readonly string _searchBoxExp = "#searchbox";
		private readonly string _cardButtonExp = ".shopping_cart";
		private readonly string _topMenuExp = "#block_top_menu";
		private readonly string _pageNavigatorExp = ".breadcrumb";

		private bool InitRoot()
		{
			if (!this.IsExist())
			{
				this._pageRoot = _driver.FindElement(By.CssSelector(_pageExp));
			}
			return this.IsExist();
		}
	   public HeaderPage(IWebDriver driver) : base(driver, _pageExp)
		{
			_driver = driver;

		}

		public IWebElement GetBanner()
		{
			if (!InitRoot())
				return null;
			return _pageRoot.FindElement(By.CssSelector(_bannerExp));
		}
		public IWebElement GetNav()
		{
			if (!InitRoot())
				return null;
			return _pageRoot.FindElement(By.CssSelector(_navigatorExp));
		}
		public IWebElement GetLogo()
		{

			if (!InitRoot())
				return null;
			return _pageRoot.FindElement(By.CssSelector(_logoExp));
		}
		public IWebElement GetSearch()
		{

			if (!InitRoot())
				return null;
			return _pageRoot.FindElement(By.CssSelector(_searchBoxExp));
		}
		public IWebElement GetCardButton()
		{

			if (!InitRoot())
				return null;
			return _pageRoot.FindElement(By.CssSelector(_cardButtonExp));
		}
		public IWebElement GetTopMenu()
		{

			if (!InitRoot())
				return null;
			return _pageRoot.FindElement(By.CssSelector(_topMenuExp));
		}

		public List<string> GetTopMenuTabsTitles()
		{
			List<string> tabsValues = new List<string>();
			var topMenu = GetTopMenu();
			if (topMenu == null)
				return null;
			var actualTabs = topMenu.FindElements(By.CssSelector(".sf-menu>li"));
			foreach (var tab in actualTabs)
			{
				tabsValues.Add(tab.Text.ToLower());
			}
			return tabsValues;
		}
	
		public IWebElement GetPageNavigator()
		{

			if (!InitRoot())
				return null;
			return _pageRoot.FindElement(By.CssSelector(_pageNavigatorExp));
		}
		public void PressOnTab(string tabName)
		{
			var topMenu = GetTopMenu();
			var button = topMenu.FindElement(By.XPath($"//li/a[text()='{tabName}']"));
			button.Click();
		}
		public IWebElement ContainerAfterTabButtonPressed(string tabName)
		{
			PressOnTab(tabName);
	
			WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));
			return wait.Until(driver => driver.FindElement(By.XPath($"//span[@class= 'category-name' and contains(text(),'{tabName}')]")));
		}

	}
}
